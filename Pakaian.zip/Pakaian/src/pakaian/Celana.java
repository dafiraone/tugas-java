/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pakaian;

/**
 *
 * @author dafiraone
 */
public class Celana {
   private String merk;
   private String warna;
   private String ukuran;

    public Celana(String merk, String warna, String ukuran) {
        this.merk = merk;
        this.warna = warna;
        this.ukuran = ukuran;
    }

    public String getMerk() {
        return merk;
    }

    public String getWarna() {
        return warna;
    }

    public String getUkuran() {
        return ukuran;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }
   
    public static void main(String[] args) {
         Celana celana = new Celana("Gucci", "Merah", "L");

         System.out.println("Merk celana: " + celana.getMerk());
         System.out.println("Warna celana: " + celana.getWarna());
         System.out.println("Ukuran celana: " + celana.getUkuran());
     }
}
