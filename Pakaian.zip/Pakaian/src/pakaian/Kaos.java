/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pakaian;

/**
 *
 * @author dafiraone
 */
public class Kaos {
    private String merk;
    private String warna;
    private String bahan;

    public Kaos(String merk, String warna, String bahan) {
        this.merk = merk;
        this.warna = warna;
        this.bahan = bahan;
    }

    public String getMerk() {
        return merk;
    }

    public String getWarna() {
        return warna;
    }

    public String getBahan() {
        return bahan;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public void setBahan(String bahan) {
        this.bahan = bahan;
    }
    
    public static void main(String[] args) {
        Kaos kaos = new Kaos("Polo", "Putih", "Nilon");
        
        System.out.println("Merk kaos: " + kaos.getMerk());
        System.out.println("Warna kaos: " + kaos.getWarna());
        System.out.println("Ukuran kaos: " + kaos.getBahan());
    }
}
