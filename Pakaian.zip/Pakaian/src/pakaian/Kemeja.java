/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pakaian;

/**
 *
 * @author dafiraone
 */
public class Kemeja {
   private String merk;
   private String warna;
   private String ukuran;

    public Kemeja(String merk, String warna, String ukuran) {
        this.merk = merk;
        this.warna = warna;
        this.ukuran = ukuran;
    }

    public String getMerk() {
        return merk;
    }

    public String getWarna() {
        return warna;
    }

    public String getUkuran() {
        return ukuran;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }
   
    public static void main(String[] args) {
        Kemeja kemeja = new Kemeja("Dior", "Hitam", "XL");
        
        System.out.println("Merk kemeja: " + kemeja.getMerk());
        System.out.println("Warna kemeja: " + kemeja.getWarna());
        System.out.println("Ukuran kemeja: " + kemeja.getUkuran());
    }
}