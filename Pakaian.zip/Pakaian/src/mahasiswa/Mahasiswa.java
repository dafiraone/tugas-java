/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mahasiswa;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public class Mahasiswa {
    private String nama;
    private String nrp;
    private float ipk;
    private int sks;

    public Mahasiswa(String nama, String nrp, float ipk, int sks) {
        this.nama = nama;
        this.nrp = nrp;
        this.ipk = ipk;
        this.sks = sks;
    }

    public String getNama() {
        return nama;
    }

    public String getNrp() {
        return nrp;
    }

    public float getIpk() {
        return ipk;
    }

    public int getSks() {
        return sks;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setNrp(String nrp) {
        this.nrp = nrp;
    }

    public void setIpk(float ipk) {
        this.ipk = ipk;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }
    
    public float potonganBiayaKuliah(float nominal) {
        return (float) (nominal - (nominal * 0.10));
    }
    
    public void tugas2() {
        System.out.println("Identitas Mahasiswa");
        System.out.println("Nama : " + this.getNama());
        System.out.println("NRP : " + this.getNrp());
        System.out.println("IPK : " + this.getIpk());
        System.out.println("SKS : " + this.getSks());
        
        int biayaKuliahAwal = this.getSks() * 500000;
        System.out.println("Total biaya kuliah awal : Rp. " + biayaKuliahAwal);
        System.out.println("Total potongan : 10% dari biaya kuliah (jika IPK diatas 3.90)");
        if (this.getIpk() >= 3.91) {
            System.out.println("Total biaya setelah dipotong : " + this.potonganBiayaKuliah(biayaKuliahAwal));
        } else {
            System.out.println("IPK tidak diatas 3.90, biaya kuliah tidak dipotong ");
        }
    }
    
    public static void main(String[] args) {
        ArrayList<Mahasiswa> mahasiswa = new ArrayList<>();
        
        mahasiswa.add(new Mahasiswa("Daffa", "152022003", (float) 3.91, 20));
        mahasiswa.add(new Mahasiswa("Deli", "152022001", (float) 3.90, 10));
        mahasiswa.add(new Mahasiswa("Irawan", "152022002", (float) 3.89, 30));
        
        for (Mahasiswa mhs : mahasiswa) {
            mhs.tugas2();
            System.out.println();
        }
    }
}
