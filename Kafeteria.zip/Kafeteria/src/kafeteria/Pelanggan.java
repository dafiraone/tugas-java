/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kafeteria;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public abstract class Pelanggan {
    private String nama;
    private String jurusan;

    public Pelanggan(String nama, String jurusan) {
        this.nama = nama;
        this.jurusan = jurusan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJurusan() {
        return jurusan;
    }

    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }
    
    public void getData()
    {
        System.out.println("Nama : " + this.nama);
        System.out.println("Jurusan : " + this.jurusan);
    }
    public abstract void pembayaran(int totalHarga);
}
