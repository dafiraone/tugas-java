/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kafeteria;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public class PelangganNonMembership extends Pelanggan{
    int point;

    public PelangganNonMembership(String nama, String jurusan) {
        super(nama, jurusan);
    }
    
    public void tambahPoint(int totalPembelian) {
        this.point += totalPembelian / 50000 * 5;
    }

    public void konversiPoint() {
        int rupiah = this.point * 5000;
        System.out.println("Total point: " + this.point);
        System.out.println("Total rupiah dari point: " + rupiah);
    }
    
    @Override
    public void pembayaran(int totalHarga) {
        if (totalHarga > 300000) {
            double totalHargaDiskon = totalHarga * 0.9;
            System.out.println("Total harga: " + totalHarga);
            System.out.println("Total harga setelah diskon: " + totalHargaDiskon);
        } else {
            System.out.println("Total harga: " + totalHarga);
            tambahPoint(totalHarga);
        }
    }
    
}
