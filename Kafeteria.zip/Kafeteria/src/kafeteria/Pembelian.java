/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kafeteria;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public class Pembelian {
    String nama;
    ArrayList<Barang> barangDijual;

    public Pembelian(String nama) {
        this.nama = nama;
        this.barangDijual = new ArrayList<>();
    }

    void tambahBarang(Barang barang) {
        barangDijual.add(barang);
    }

    int hitungTotalHarga() {
        int totalHarga = 0;
        for (Barang barang : barangDijual) {
            totalHarga += barang.harga * barang.jumlah;
        }
        if (totalHarga > 100000) {
            totalHarga *= 0.8; // Diskon 20%
        }
        return (int) Math.ceil(totalHarga / 100) * 100; // Pembulatan ke atas per 100
    }

    void displayBarang() {
        for (Barang barang : barangDijual) {
            barang.getData();
        }
    }
    
    
}
