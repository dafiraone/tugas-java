/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kafeteria;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public class PelangganMembership extends Pelanggan {

    public PelangganMembership(String nama, String jurusan) {
        super(nama, jurusan);
    }
    
    @Override
    public void pembayaran(int totalHarga) {
        double totalHargaDiskon = totalHarga * 0.8;
        System.out.println("Total harga : " + totalHarga);
        System.out.println("Total harga setelah diskon: " + totalHargaDiskon);
    }
}
