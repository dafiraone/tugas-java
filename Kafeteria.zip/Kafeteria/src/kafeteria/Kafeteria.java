/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kafeteria;

/**
 *
 * @author dafiraone
 */
public class Kafeteria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pelanggan pelanggan1 = new PelangganMembership("Daffa", "Informatika");
        pelanggan1.getData();

        Pembelian pembelian1 = new Pembelian("Pembelian Daffa");
        Barang barang1 = new Barang("Tomyam", 15000, 2);
        Barang barang2 = new Barang("Teh Manis", 5000, 3);
        pembelian1.tambahBarang(barang1);
        pembelian1.tambahBarang(barang2);
        pembelian1.displayBarang();

        int totalHarga = pembelian1.hitungTotalHarga();
        pelanggan1.pembayaran(totalHarga);

        Pelanggan pelanggan2 = new PelangganNonMembership("Irawan", "IF");
        pelanggan2.getData();

        Pembelian pembelian2 = new Pembelian("Pembelian Irawan");
        Barang barang3 = new Barang("Nasi Goreng", 20000, 20);
        Barang barang4 = new Barang("Es Teh", 6000, 2);
        pembelian2.tambahBarang(barang3);
        pembelian2.tambahBarang(barang4);
        pembelian2.displayBarang();

        totalHarga = pembelian2.hitungTotalHarga();
        pelanggan2.pembayaran(totalHarga);
        
        if (pelanggan2 instanceof PelangganNonMembership) {
            ((PelangganNonMembership) pelanggan2).tambahPoint(totalHarga);
        }
        
        ((PelangganNonMembership) pelanggan2).konversiPoint();
    }
    
}
