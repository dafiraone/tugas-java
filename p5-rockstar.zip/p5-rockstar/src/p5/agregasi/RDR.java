/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p5.agregasi;

/**
 *
 * @author dafiraone
 */
public class RDR {
    private String judul, genre, publisher;

    public RDR(String judul, String genre, String publisher) {
        this.judul = judul;
        this.genre = genre;
        this.publisher = publisher;
    }

    public String getJudul() {
        return judul;
    }

    public String getGenre() {
        return genre;
    }
    
    public String getPublisher() {
        return publisher;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    
    public void print() {
        System.out.println("Judul game : " + this.getJudul());
        System.out.println("Publisher : " + this.getPublisher());
        System.out.println("Genre : " + this.getGenre());
        System.out.println("");
    }
}
