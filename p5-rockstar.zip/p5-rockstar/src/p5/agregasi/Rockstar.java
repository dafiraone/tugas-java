/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p5.agregasi;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public class Rockstar {
    private ArrayList<GTA> gta = new ArrayList<>();
    private ArrayList<RDR> rdr = new ArrayList<>();
    
    public void addGta(GTA g) {
        this.gta.add(g);
    }
    
    public void addRdr(RDR r) {
        this.rdr.add(r);
    }
    
    public void print() {
        for (GTA g : gta) {
            g.print();
        }
        
        for (RDR r : rdr) {
            r.print();
        }
    }
}
