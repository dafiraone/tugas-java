/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p5.agregasi;

/**
 *
 * @author dafiraone
 */
public class P5Agregasi {
    public static void main(String[] args) {
        Rockstar rockstar = new Rockstar();
        
        GTA gtaiii = new GTA("GTA III", "Rockstar", 100000);
        rockstar.addGta(gtaiii);
        GTA gtaiv = new GTA("GTA IV", "Rockstar", 120000);
        rockstar.addGta(gtaiv);
        GTA gtav = new GTA("GTA V", "Rockstar", 150000);
        rockstar.addGta(gtav);
        
        RDR rdr1 = new RDR("Red Dead Redemption 1", "Open world", "Rockstar");
        rockstar.addRdr(rdr1);
        
        RDR rdr2 = new RDR("Red Dead Redemption 2", "Wild West", "Rockstar");
        rockstar.addRdr(rdr2);
        
        rockstar.print();
    }
}
