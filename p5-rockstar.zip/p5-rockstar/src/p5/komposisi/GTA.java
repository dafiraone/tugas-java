/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p5.komposisi;

/**
 *
 * @author dafiraone
 */
public class GTA {
    private String judul, publisher;
    private int harga;

    public GTA(String judul, String publisher, int harga) {
        this.judul = judul;
        this.publisher = publisher;
        this.harga = harga;
    }

    public String getJudul() {
        return judul;
    }
    
    public String getPublisher() {
        return publisher;
    }

    public int getHarga() {
        return harga;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }
    
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }
    
    
    
    public void print() {
        System.out.println("Judul game : " + this.getJudul());
        System.out.println("Publisher : " + this.getPublisher());
        System.out.println("Harga : " + this.getHarga());
        System.out.println("");
    }
}
