/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p5.komposisi;

/**
 *
 * @author dafiraone
 */
public class Rockstar {
    private GTA gta;
    private RDR rdr;

    public Rockstar(String judulGta, String judulRdr, int hargaGta, String genreRdr, String publisher) {
        gta = new GTA(judulGta, publisher, hargaGta);
        rdr = new RDR(judulRdr, genreRdr, publisher);
    }
    
    public void print() {
        gta.print();
        rdr.print();
    }
}
