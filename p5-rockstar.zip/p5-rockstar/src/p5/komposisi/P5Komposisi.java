/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package p5.komposisi;

/**
 *
 * @author dafiraone
 */
public class P5Komposisi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rockstar rockstar = new Rockstar("GTA V", "RDR2", 150000, "Open World", "Rockstar");
        rockstar.print();
    }
    
}
