/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oop8exceptionhandling;

/**
 *
 * @author dafiraone
 */
public class OOP8ExceptionHandling {

    /**
     * @param a
     * @param b
     * @param args the command line arguments
     * @return 
     */
    public static int pembagian(int a, int b) {
        if (b == 0) throw new ArithmeticException("Pembagian Terhadap nol tidak diperbolehkan");
        return a/b;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            System.out.println(pembagian(10, 5));
            System.out.println(pembagian(0, 5));
            pembagian(5, 0); // Error Disini
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            System.out.println("Ini adalah Finally");
        }
    }
    
}
