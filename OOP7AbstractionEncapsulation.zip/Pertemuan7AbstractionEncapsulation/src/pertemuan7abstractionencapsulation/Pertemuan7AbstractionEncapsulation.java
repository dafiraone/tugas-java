/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan7abstractionencapsulation;

/**
 *
 * @author dafiraone
 */

interface Bergerak {
    void bergerak();
}

abstract class Karakter implements Bergerak {
    private int kesehatan;
    private int kecepatan;

    public Karakter(int kesehatan, int kecepatan) {
        this.kesehatan = kesehatan;
        this.kecepatan = kecepatan;
    }

    public void terkenaSerangan(int kerusakan) {
        kesehatan -= kerusakan;
        if (kesehatan <= 0) {
            System.out.println("Karakter telah kalah!");
        }
    }

    // Getter untuk kesehatan
    public int getKesehatan() {
        return kesehatan;
    }
}

class Pemain extends Karakter {
    public Pemain(int kesehatan, int kecepatan) {
        super(kesehatan, kecepatan);
    }

    @Override
    public void bergerak() {
        System.out.println("Pemain sedang bergerak");
    }

    public void lompat() {
        System.out.println("Pemain sedang melompat");
    }
}


public class Pertemuan7AbstractionEncapsulation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Membuat karakter pemain
        Pemain pemain = new Pemain(100, 10);

        // Berinteraksi dengan karakter pemain
        pemain.bergerak();
        pemain.lompat();
        pemain.terkenaSerangan(20);
        System.out.println("Kesehatan pemain: " + pemain.getKesehatan());
    }
    
}
