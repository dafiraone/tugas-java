/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacexyzcorp;

/**
 *
 * @author dafiraone
 */
public class Sales implements Pegawai {
    private float komisi;
    private String nama;
    private float gajiPokok;

    public Sales(float komisi, String nama, float gajiPokok) {
        this.komisi = komisi;
        this.nama = nama;
        this.gajiPokok = gajiPokok;
    }

    @Override
    public float hitungGajiTotal() {
        System.out.println("Sales: " + this.nama);
        System.out.println("Gaji Pokok: " + this.gajiPokok);
        System.out.println("Komisi: " + this.komisi);
        return this.gajiPokok + komisi;
    }
    
}
