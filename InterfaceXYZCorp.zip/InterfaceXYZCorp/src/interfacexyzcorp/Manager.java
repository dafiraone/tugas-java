/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacexyzcorp;

/**
 *
 * @author dafiraone
 */
public class Manager implements Pegawai {
    private float bonus;
    private String nama;
    private float gajiPokok;

    public Manager(float bonus, String nama, float gajiPokok) {
        this.bonus = bonus;
        this.nama = nama;
        this.gajiPokok = gajiPokok;
    }
    
    @Override
    public float hitungGajiTotal() {
        System.out.println("Manager: " + this.nama);
        System.out.printf("Gaji Pokok: %.1f \n", this.gajiPokok);
        System.out.println("Bonus: " + this.bonus);
        return this.gajiPokok + this.bonus;
    }
    
}
