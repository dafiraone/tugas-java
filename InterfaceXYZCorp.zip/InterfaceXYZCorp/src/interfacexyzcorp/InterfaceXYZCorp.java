/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfacexyzcorp;

/**
 *
 * @author dafiraone
 */
public class InterfaceXYZCorp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Manager manager1 = new Manager(2000000, "Manager1XYZ", 10000000);
        Karyawan karyawan1 = new Karyawan("Karyawan1XYZ", 8000000);
        Sales sales1 = new Sales(200000, "Sales1XYZ", 5000000);
        
        Pegawai[] pegawai = {manager1, karyawan1, sales1};
        
        for(Pegawai peg : pegawai)
        {
            System.out.printf("Gaji Total: %.1f\n", peg.hitungGajiTotal());
        }
    }
    
}
