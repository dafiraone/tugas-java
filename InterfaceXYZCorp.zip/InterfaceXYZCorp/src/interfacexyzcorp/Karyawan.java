/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacexyzcorp;

/**
 *
 * @author dafiraone
 */
public class Karyawan implements Pegawai {
    private String nama;
    private float gajiPokok;

    public Karyawan(String nama, float gajiPokok) {
        this.nama = nama;
        this.gajiPokok = gajiPokok;
    }

    @Override
    public float hitungGajiTotal() {
        System.out.println("Karyawan: " + this.nama);
        System.out.println("Gaji Pokok: " + this.gajiPokok);
        return this.gajiPokok;
    }
    
}
