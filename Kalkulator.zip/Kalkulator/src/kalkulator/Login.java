package kalkulator;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager.LookAndFeelInfo;

public class Login extends JFrame {
   private JButton btnLogin;
   private JLabel jLabel1;
   private JLabel jLabel2;
   private JLabel jLabel3;
   private JLabel lblPesan;
   private JPasswordField txtPassword;
   private JTextField txtUsername;

   public Login() {
      this.initComponents();
   }

   private void initComponents() {
      this.jLabel1 = new JLabel();
      this.jLabel2 = new JLabel();
      this.txtUsername = new JTextField();
      this.txtPassword = new JPasswordField();
      this.btnLogin = new JButton();
      this.lblPesan = new JLabel();
      this.jLabel3 = new JLabel();
      this.setDefaultCloseOperation(3);
      this.jLabel1.setText("Username :");
      this.jLabel2.setText("Password :");
      this.txtUsername.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Login.this.txtUsernameActionPerformed(evt);
         }
      });
      this.btnLogin.setText("Login");
      this.btnLogin.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Login.this.btnLoginActionPerformed(evt);
         }
      });
      this.lblPesan.setForeground(new Color(255, 0, 0));
      this.lblPesan.setHorizontalAlignment(0);
      this.jLabel3.setFont(new Font("Segoe UI", 0, 18));
      this.jLabel3.setText("Form Login");
      GroupLayout layout = new GroupLayout(this.getContentPane());
      this.getContentPane().setLayout(layout);
      layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(39, 39, 39).addComponent(this.lblPesan, -2, 319, -2)).addGroup(layout.createSequentialGroup().addGap(151, 151, 151).addComponent(this.btnLogin)).addGroup(layout.createSequentialGroup().addGap(55, 55, 55).addGroup(layout.createParallelGroup(Alignment.TRAILING, false).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1).addPreferredGap(ComponentPlacement.RELATED, -1, 32767).addComponent(this.txtUsername, -2, 71, -2)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel2).addGap(42, 42, 42).addComponent(this.txtPassword, -2, 71, -2))))).addContainerGap(-1, 32767)).addGroup(Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jLabel3).addContainerGap(-1, 32767)));
      layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(14, 14, 14).addComponent(this.jLabel3).addGap(34, 34, 34).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.jLabel1).addComponent(this.txtUsername, -2, -1, -2)).addGap(28, 28, 28).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.txtPassword, -2, -1, -2).addComponent(this.jLabel2)).addGap(67, 67, 67).addComponent(this.lblPesan).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.btnLogin).addContainerGap(59, 32767)));
      this.pack();
   }

   private void txtUsernameActionPerformed(ActionEvent evt) {
   }

   private void btnLoginActionPerformed(ActionEvent evt) {
      String username = this.txtUsername.getText();
      String password = String.valueOf(this.txtPassword.getPassword());
      System.out.println(username);
      System.out.println(password);
      if (username.equals("kalkulator") && password.equals("calc")) {
         (new Kalkulator()).setVisible(true);
         this.dispose();
      } else if (username.equals("bmi") && password.equals("bmi")) {
         (new HitungBMI()).setVisible(true);
         this.dispose();
      } else {
         this.txtUsername.setText("");
         this.txtPassword.setText("");
         this.lblPesan.setText("Username / Password salah");
      }

   }

   public static void main(String[] args) {
      try {
         LookAndFeelInfo[] var1 = UIManager.getInstalledLookAndFeels();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            LookAndFeelInfo info = var1[var3];
            if ("Nimbus".equals(info.getName())) {
               UIManager.setLookAndFeel(info.getClassName());
               break;
            }
         }
      } catch (ClassNotFoundException var5) {
         Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var5);
      } catch (InstantiationException var6) {
         Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var6);
      } catch (IllegalAccessException var7) {
         Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var7);
      } catch (UnsupportedLookAndFeelException var8) {
         Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var8);
      }

      EventQueue.invokeLater(new Runnable() {
         public void run() {
            (new Login()).setVisible(true);
         }
      });
   }
}
