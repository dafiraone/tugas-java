/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kalkulator;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager.LookAndFeelInfo;

/**
 *
 * @author dafiraone
 */
public class Kalkulator extends JFrame {
   private JButton btnAkarKuadrat;
   private JButton btnBagi;
   private JButton btnKali;
   private JButton btnKurang;
   private JButton btnTambah;
   private JTextField hasil;
   private JLabel jLabel1;
   private JTextField txt1;
   private JTextField txt2;

   public Kalkulator() {
      this.initComponents();
   }

   private void initComponents() {
      this.txt1 = new JTextField();
      this.txt2 = new JTextField();
      this.btnTambah = new JButton();
      this.btnKurang = new JButton();
      this.btnKali = new JButton();
      this.btnBagi = new JButton();
      this.hasil = new JTextField();
      this.jLabel1 = new JLabel();
      this.btnAkarKuadrat = new JButton();
      this.setDefaultCloseOperation(3);
      this.txt1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.txt1ActionPerformed(evt);
         }
      });
      this.txt2.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.txt2ActionPerformed(evt);
         }
      });
      this.btnTambah.setText("Tambah");
      this.btnTambah.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.btnTambahActionPerformed(evt);
         }
      });
      this.btnKurang.setText("Kurang");
      this.btnKurang.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.btnKurangActionPerformed(evt);
         }
      });
      this.btnKali.setText("Kali");
      this.btnKali.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.btnKaliActionPerformed(evt);
         }
      });
      this.btnBagi.setText("Bagi");
      this.btnBagi.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.btnBagiActionPerformed(evt);
         }
      });
      this.jLabel1.setFont(new Font("Segoe UI", 1, 18));
      this.jLabel1.setText("Kalkulator");
      this.btnAkarKuadrat.setText("Akar Kuadrat");
      this.btnAkarKuadrat.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            Kalkulator.this.btnAkarKuadratActionPerformed(evt);
         }
      });
      GroupLayout layout = new GroupLayout(this.getContentPane());
      this.getContentPane().setLayout(layout);
      layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(Alignment.TRAILING, layout.createSequentialGroup().addGap(63, 63, 63).addComponent(this.txt1, -2, 71, -2).addPreferredGap(ComponentPlacement.RELATED, -1, 32767).addComponent(this.txt2, -2, 71, -2).addGap(79, 79, 79)).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(16, 16, 16).addComponent(this.btnTambah).addGap(18, 18, 18).addComponent(this.btnKurang).addGap(18, 18, 18).addComponent(this.btnKali).addGap(28, 28, 28).addComponent(this.btnBagi)).addGroup(layout.createSequentialGroup().addGap(66, 66, 66).addComponent(this.hasil, -2, 259, -2)).addGroup(layout.createSequentialGroup().addGap(149, 149, 149).addComponent(this.jLabel1)).addGroup(layout.createSequentialGroup().addGap(138, 138, 138).addComponent(this.btnAkarKuadrat))).addContainerGap(31, 32767)));
      layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(24, 24, 24).addComponent(this.jLabel1).addGap(28, 28, 28).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.txt1, -2, -1, -2).addComponent(this.txt2, -2, -1, -2)).addGap(30, 30, 30).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.btnTambah).addComponent(this.btnKurang).addComponent(this.btnKali).addComponent(this.btnBagi)).addPreferredGap(ComponentPlacement.UNRELATED).addComponent(this.btnAkarKuadrat).addGap(28, 28, 28).addComponent(this.hasil, -2, -1, -2).addContainerGap(63, 32767)));
      this.pack();
   }

   private void txt1ActionPerformed(ActionEvent evt) {
   }

   private void btnKurangActionPerformed(ActionEvent evt) {
      int angka1 = Integer.parseInt(this.txt1.getText());
      int angka2 = Integer.parseInt(this.txt2.getText());
      int hasil = angka1 - angka2;
      this.hasil.setText(Integer.toString(hasil));
   }

   private void btnTambahActionPerformed(ActionEvent evt) {
      int angka1 = Integer.parseInt(this.txt1.getText());
      int angka2 = Integer.parseInt(this.txt2.getText());
      int hasil = angka1 + angka2;
      this.hasil.setText(Integer.toString(hasil));
   }

   private void txt2ActionPerformed(ActionEvent evt) {
   }

   private void btnKaliActionPerformed(ActionEvent evt) {
      int angka1 = Integer.parseInt(this.txt1.getText());
      int angka2 = Integer.parseInt(this.txt2.getText());
      int hasil = angka1 * angka2;
      this.hasil.setText(Integer.toString(hasil));
   }

   private void btnBagiActionPerformed(ActionEvent evt) {
      int angka1 = Integer.parseInt(this.txt1.getText());
      int angka2 = Integer.parseInt(this.txt2.getText());

      try {
         int hasil = angka1 / angka2;
         this.hasil.setText(Integer.toString(hasil));
      } catch (Exception var5) {
         this.hasil.setText("Error");
      }

   }

   private void btnAkarKuadratActionPerformed(ActionEvent evt) {
      int angka1 = Integer.parseInt(this.txt1.getText());
      double hasil = Math.sqrt((double)angka1);
      this.hasil.setText(Double.toString(hasil));
   }

   public static void main(String[] args) {
      try {
         LookAndFeelInfo[] var1 = UIManager.getInstalledLookAndFeels();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            LookAndFeelInfo info = var1[var3];
            if ("Nimbus".equals(info.getName())) {
               UIManager.setLookAndFeel(info.getClassName());
               break;
            }
         }
      } catch (ClassNotFoundException var5) {
         Logger.getLogger(Kalkulator.class.getName()).log(Level.SEVERE, (String)null, var5);
      } catch (InstantiationException var6) {
         Logger.getLogger(Kalkulator.class.getName()).log(Level.SEVERE, (String)null, var6);
      } catch (IllegalAccessException var7) {
         Logger.getLogger(Kalkulator.class.getName()).log(Level.SEVERE, (String)null, var7);
      } catch (UnsupportedLookAndFeelException var8) {
         Logger.getLogger(Kalkulator.class.getName()).log(Level.SEVERE, (String)null, var8);
      }

      EventQueue.invokeLater(new Runnable() {
         public void run() {
            (new Kalkulator()).setVisible(true);
         }
      });
   }
}
