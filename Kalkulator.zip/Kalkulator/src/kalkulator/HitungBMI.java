package kalkulator;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager.LookAndFeelInfo;

public class HitungBMI extends JFrame {
   private JTextField beratBadan;
   private JButton btnHitung;
   private JTextField hasil;
   private JLabel infoBMI;
   private JLabel jLabel1;
   private JLabel jLabel2;
   private JLabel jLabel3;
   private JTextField tinggiBadan;

   public HitungBMI() {
      this.initComponents();
   }

   private void initComponents() {
      this.beratBadan = new JTextField();
      this.tinggiBadan = new JTextField();
      this.btnHitung = new JButton();
      this.hasil = new JTextField();
      this.jLabel1 = new JLabel();
      this.jLabel2 = new JLabel();
      this.jLabel3 = new JLabel();
      this.infoBMI = new JLabel();
      this.setDefaultCloseOperation(3);
      this.beratBadan.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            HitungBMI.this.beratBadanActionPerformed(evt);
         }
      });
      this.btnHitung.setText("Hitung");
      this.btnHitung.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent evt) {
            HitungBMI.this.btnHitungActionPerformed(evt);
         }
      });
      this.jLabel1.setText("Berat Badan (Kg) :");
      this.jLabel2.setText("Tinggi Badan (Cm) :");
      this.jLabel3.setFont(new Font("Segoe UI", 1, 18));
      this.jLabel3.setText("Hitung BMI");
      this.infoBMI.setHorizontalAlignment(0);
      GroupLayout layout = new GroupLayout(this.getContentPane());
      this.getContentPane().setLayout(layout);
      layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(140, 140, 140).addComponent(this.jLabel3)).addGroup(layout.createSequentialGroup().addGap(44, 44, 44).addGroup(layout.createParallelGroup(Alignment.TRAILING).addComponent(this.jLabel2).addComponent(this.jLabel1)).addPreferredGap(ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(Alignment.LEADING, false).addComponent(this.btnHitung, -1, -1, 32767).addComponent(this.hasil).addComponent(this.tinggiBadan, Alignment.TRAILING).addComponent(this.beratBadan, -2, 72, -2))).addGroup(layout.createSequentialGroup().addGap(44, 44, 44).addComponent(this.infoBMI, -2, 288, -2))).addContainerGap(68, 32767)));
      layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(20, 20, 20).addComponent(this.jLabel3).addGap(40, 40, 40).addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.jLabel1).addComponent(this.beratBadan, -2, -1, -2)).addGap(26, 26, 26).addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.tinggiBadan, -2, -1, -2).addComponent(this.jLabel2)).addGap(32, 32, 32).addComponent(this.btnHitung).addGap(18, 18, 18).addComponent(this.hasil, -2, -1, -2).addGap(18, 18, 18).addComponent(this.infoBMI).addContainerGap(32, 32767)));
      this.pack();
   }

   private void beratBadanActionPerformed(ActionEvent evt) {
   }

   private void btnHitungActionPerformed(ActionEvent evt) {
      double beratBadan = Double.parseDouble(this.beratBadan.getText());
      double tinggiBadan = Math.pow(Double.parseDouble(this.tinggiBadan.getText()) / 100.0D, 2.0D);
      if (tinggiBadan >= 0.0D) {
         double bmi = beratBadan / tinggiBadan;
         this.hasil.setText(String.valueOf(Math.round(bmi * 100.0D) / 100L));
         if (bmi < 17.0D) {
            this.infoBMI.setText("Kekurangan berat badan tingkat berat");
         } else if (bmi >= 17.0D && bmi < 18.5D) {
            this.infoBMI.setText("Kekurangan berat badan tingkat rendah");
         } else if (bmi >= 18.5D && bmi < 25.0D) {
            this.infoBMI.setText("Normal");
         } else if (bmi >= 25.0D && bmi <= 27.0D) {
            this.infoBMI.setText("Kelebihan berat badan tingkat rendah");
         } else if (bmi > 27.0D) {
            this.infoBMI.setText("Kelebihan berat badan tingkat berat");
         }
      } else {
         this.hasil.setText("Error");
      }

   }

   public static void main(String[] args) {
      try {
         LookAndFeelInfo[] var1 = UIManager.getInstalledLookAndFeels();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            LookAndFeelInfo info = var1[var3];
            if ("Nimbus".equals(info.getName())) {
               UIManager.setLookAndFeel(info.getClassName());
               break;
            }
         }
      } catch (ClassNotFoundException var5) {
         Logger.getLogger(HitungBMI.class.getName()).log(Level.SEVERE, (String)null, var5);
      } catch (InstantiationException var6) {
         Logger.getLogger(HitungBMI.class.getName()).log(Level.SEVERE, (String)null, var6);
      } catch (IllegalAccessException var7) {
         Logger.getLogger(HitungBMI.class.getName()).log(Level.SEVERE, (String)null, var7);
      } catch (UnsupportedLookAndFeelException var8) {
         Logger.getLogger(HitungBMI.class.getName()).log(Level.SEVERE, (String)null, var8);
      }

      EventQueue.invokeLater(new Runnable() {
         public void run() {
            (new HitungBMI()).setVisible(true);
         }
      });
   }
}
