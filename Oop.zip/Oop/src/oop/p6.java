/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop;

/**
 *
 * @author dafiraone
 */

class ContohOverloading {
    // Method overloading dengan mengubah tipe data
    static void display(int num) {
        System.out.println("Displaying integer: " + num);
    }
    
    static void display(double num) {
        System.out.println("Displaying double: " + num);
    }
    
    // Method overloading dengan menambah argumen
    static void display(String str) {
        System.out.println("Displaying string: " + str);
    }
    
    static void display(String str1, String str2) {
        System.out.println("Displaying strings: " + str1 + " and " + str2);
    }
}

public class p6 {
    public static void main(String[] args) {
        ContohOverloading ovrload = new ContohOverloading();
    // Method overloading dengan mengubah tipe data
    ovrload.display(10);
    ovrload.display(10.5);
    // Method overloading dengan menambah argumen
    ovrload.display("Hello");
    ovrload.display("Hello", "World");
    }
}
