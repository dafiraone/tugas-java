/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop;

/**
 *
 * @author dafiraone
 */

class Frame  {}

class Window extends Frame {
    public void open(){
        System.out.println("open window...");
    
    }
    public void close(){
        System.out.println("close window...");
    }
    public void move(){
        System.out.println("move window...");
    }
    public void display(){
        System.out.println("display window..");
    }
    public void handleevent(){
        
    }
    
}

class Event {
    //dependency
    public Window window=new Window();  
}

class Consolewindow extends Window {
    @Override
    public void open(){
        System.out.println("open console...");
    
    }
    @Override
    public void close(){
        System.out.println("close console...");
    }
    @Override
    public void move(){
        System.out.println("move console...");
    }
    @Override
    public void display(){
        System.out.println("display console..");
    }
    @Override
    public void handleevent(){
        
    }
}

class Dialogbox extends Window {
    @Override
    public void open(){
        System.out.println("open dialogbox...");
    
    }
    @Override
    public void close(){
        System.out.println("close dialogbox...");
    }
    @Override
    public void move(){
        System.out.println("move dialogbox...");
    }
    @Override
    public void display(){
        System.out.println("display dialogbox..");
    }
    @Override
    public void handleevent(){
        
    }
}

class Datacontroller {
    public Dialogbox dial=new Dialogbox();   
}


class Drawingcontext {
    
   public void setpoint(){}
   public void clearscreen(){
   System.out.println("clearing screen....");
   }
   public void getverticalsize(){
   System.out.println("200");
   }
   public void gethorizontalsize(){
   System.out.println("400");
   }
    
}

class Point {
    public void getpoint(){
    System.out.print("circle does not point");
    }
}

abstract class Shape {
    public void draw(){
    System.out.println("draw shape...");
    }
    public void erase(){
    System.out.println("erase shape...");
    }
    public void move(){
    System.out.println("move shape...");
    }
    public void resize(){
    System.out.println("resize shape...");
    }
}

class Polygon extends Shape {
@Override
    public void draw(){
        System.out.println("draw polygon....");
    }
    
    @Override
    public void erase(){
        System.out.println("erase polygon...");
    }
    @Override
    public void move(){
        System.out.println("move polygon...");
    }  
    @Override
    public void resize(){
        System.out.println("resize polygon...");
    }
        
}

class Retangle extends Shape {
    
    @Override
    public void draw(){
        System.out.println("draw retangle....");
    }
    
    @Override
    public void erase(){
        System.out.println("erase retangle...");
    }
    @Override
    public void move(){
        System.out.println("move retangle...");
    }  
    @Override
    public void resize(){
        System.out.println("resize retangle...");
    }
    
}

class Circle extends Shape {
    private float radius;
    private int center;
    //composisi
    public Point point;
    
    public Circle(float pradius,int pcenter){
        this.center=pcenter;
        this.radius=pradius;
    
    }

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    public int getCenter() {
        return center;
    }

    public void setCenter(int center) {
        this.center = center;
    }
    //composisi objek
    public void getpoint(){
    point=new Point();
    }
    
    @Override
    public void draw(){
        System.out.println("draw circle....");
    }
    
    @Override
    public void erase(){
        System.out.println("erase circle...");
    }
    @Override
    public void move(){
        System.out.println("move circle...");
    }  
    @Override
    public void resize(){
        System.out.println("resize circle...");
    }
}


public class p4 {
    public static void main(String[] args) {
        Window window1=new Window();
        window1.close();
        window1.display();
        window1.open();
        window1.move();
        
        Consolewindow console1=new Consolewindow();
        console1.close();
        console1.display();
        console1.move();
        console1.open();
        
        Dialogbox dial1=new Dialogbox();
        dial1.close();
        dial1.display();
        dial1.move();
        dial1.open();
        
        Drawingcontext drawingcontext1=new Drawingcontext();
        drawingcontext1.clearscreen();
        drawingcontext1.setpoint();
        drawingcontext1.gethorizontalsize();
        drawingcontext1.getverticalsize();
        
        Retangle retangle1=new Retangle();
        retangle1.draw();
        retangle1.erase();
        retangle1.move();
        retangle1.resize();
        
        Polygon polygon1=new Polygon();
        polygon1.draw();
        polygon1.erase();
        polygon1.move();
        polygon1.resize();
        
        Circle circle1=new Circle(200,50);
        circle1.getRadius();
        circle1.getCenter();
        circle1.draw();
        circle1.move();
        circle1.erase();
        circle1.getpoint();
    }
}
