/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop;

/**
 *
 * @author dafiraone
 */

class Animal {
    String color;

    public Animal(String color) {
        this.color = color;
    }
            
    void eat() {
        System.out.println("Animal is eating...");
    }
}

class Dog extends Animal {
    String breed;

    public Dog(String breed, String color) {
        super(color);
        this.breed = breed;
    }
    
    void displayInfo() {
        System.out.println("Color of the dog: " + color);
        System.out.println("Breed of the dog: " + breed);
    }
    
    void bark() {
        System.out.println("Dog is barking...");
    }
}

class Husky extends Dog {

    public Husky(String breed, String color) {
        super(breed, color);
    }
    
    void color() {
        System.out.println("Labrador is brown in color...");
    }
}

class Cat extends Animal {

    public Cat(String color) {
        super(color);
    }
    void meow() {
        System.out.println("Cat is meowing...");
    }
}

class Cheetah extends Animal {

    public Cheetah(String color) {
        super(color);
    }
    void roar() {
        System.out.println("Cheetah is roaring...");
    }
}

interface A {
    void methodA();
}

interface B {
    void methodB();
}

class ForImplements implements A, B {

    @Override
    public void methodA() {
        System.out.println("Implement method A");
    }

    @Override
    public void methodB() {
        System.out.println("Implement method B");
    }
    
}

public class p5 {
    
    public static void main(String[] args) {
        // Multilevel Inheritance
        Husky oreo = new Husky("Husky", "Grey");
        oreo.eat();
        oreo.color();
        oreo.bark();
        
        // Hierarchical Inheritance
        Cat oyen = new Cat("Orange");
        oyen.eat();
        oyen.meow();
        Cheetah simba = new Cheetah("Yellow");
        simba.eat();
        simba.roar();

        // Multiple Interface
        ForImplements obj = new ForImplements();
        obj.methodA();
        obj.methodB();
        
        // super()
        Dog dog = new Dog("Brown", "Labrador");
        dog.displayInfo();
    }
    
}
