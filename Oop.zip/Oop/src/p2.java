import java.util.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dafiraone
 */

class Anak{
    int NIK;
    String nama;
    String alamat;
    Ayah ayahku;
    
    public Anak() {
    }
    
    public Anak(int NIK, String namal) {
        this.NIK = NIK;
        this.nama = namal;
    }
    
    public int getNIK() {
        return NIK;
    }
    
    public void setNIK(int nIK) {
        this.NIK = nIK;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public void setAyahku(Ayah ayahku) {
        this.ayahku = ayahku;
    }
}

class Ayah {
    String nama;
    List<Anak> anak;
    
    Ayah(String nama){
        this.nama=nama;
    };
    
    public void setAnak(List<Anak> anak) {
        this.anak=anak;
    }
    public List<Anak> getAnak() {
        return this.anak;
    }
}

public class p2 {
    
    public static void main(String[] args) {
        Anak unyil=new Anak(); //kita buat objek anak dgn nama unyil
        Anak usro=new Anak(); //kita buat objek anak dgn nama usro
        
        unyil.setNIK(15202201);
        unyil.setNama("Unyil Surunyil");
        usro.setNIK(15202202);
        usro.setNama("Usro Suroso");
        Ayah ogah=new Ayah("Ogah Surogah");
        List <Anak> anak2=new ArrayList<>(); //sampai sini list masih kosong
        anak2.add(unyil);
        anak2.add(usro); // sampai sini list sdh berisi 2 anak
        ogah.setAnak(anak2); //sampai sini ayah ogah sdh punya anak2
        unyil.setAyahku(ogah); //sampai sini unyil punya ayah ogah
        usro.setAyahku(ogah); //sampai sini usro punya ayah ogah
    }
    
}
