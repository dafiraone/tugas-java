/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bangunruang;

import java.util.ArrayList;

/**
 *
 * @author dafiraone
 */
public class BangunRuang {
    public static void main(String[] args) {
//        ArrayList<NamaBangun> bangun = new ArrayList<>();
    
//        bangun.add(new Balok(2, 3, 4, "Balok1"));
//        bangun.add(new Kubus(2, "Kubus1"));
//        bangun.add(new Bola(3, "Bola1"));

        Balok balok = new Balok(2, 3, 4, "Balok1");
        Kubus kubus = new Kubus(2, "Kubus1");
        Bola bola = new Bola(3, "Bola1");
        
        NamaBangun[] bangun = {balok, kubus, bola};
        for (NamaBangun b : bangun) {
            b.volume();
        }
    }
}
