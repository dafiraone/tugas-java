/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bangunruang;

/**
 *
 * @author dafiraone
 */
public class Balok extends NamaBangun {
    protected float p, l, t;

    public Balok(float p, float l, float t, String nama_bangun) {
        super(nama_bangun);
        this.p = p;
        this.l = l;
        this.t = t;
    }
    
    @Override
    public void volume()
    {
        System.out.println("Panjang: " + this.p);
        System.out.println("Lebar: " + this.l);
        System.out.println("Tinggi: " + this.t);
        float volume = this.p * this.l * this.t;
        System.out.println("Volume " + this.nama_bangun + ": " + volume);
    }
}
