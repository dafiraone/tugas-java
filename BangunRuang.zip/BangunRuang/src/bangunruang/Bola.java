/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bangunruang;

/**
 *
 * @author dafiraone
 */
public class Bola extends NamaBangun {
    protected float jari;

    public Bola(float jari, String nama_bangun) {
        super(nama_bangun);
        this.jari = jari;
    }
    
    @Override
    public void volume()
    {
        System.out.println("Jari-jari: " + jari);
        float volume = (float) ((4.0/3.0) * Math.PI * Math.pow(jari, 3));
        System.out.println("Volume " + this.nama_bangun + ": " + volume);
    }
    
}
