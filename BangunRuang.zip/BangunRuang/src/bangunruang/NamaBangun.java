/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bangunruang;

/**
 *
 * @author dafiraone
 */
public class NamaBangun {
    protected String nama_bangun;

    public NamaBangun(String nama_bangun) {
        this.nama_bangun = nama_bangun;
    }
    
    public void volume(){}

    public String getNama_bangun() {
        return nama_bangun;
    }

//    @Override
//    public String toString() {
//        return "NamaBangun{" + "nama_bangun=" + nama_bangun + '}';
//    }
    
    
}
