/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bangunruang;

/**
 *
 * @author dafiraone
 */
public class Kubus extends NamaBangun {
    protected float sisi;

    public Kubus(float sisi, String nama_bangun) {
        super(nama_bangun);
        this.sisi = sisi;
    }
    
    @Override
    public void volume()
    {
        System.out.println("SIsi: " + this.sisi);
        System.out.println("Volume " + this.nama_bangun + ": " + Math.pow(sisi, 3));
    }
    
}
