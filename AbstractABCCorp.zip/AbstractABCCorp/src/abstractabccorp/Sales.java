/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractabccorp;

/**
 *
 * @author dafiraone
 */
public class Sales extends Pegawai {
    private float komisi;

    public Sales(String nama, float gajiPokok, float komisi) {
        super(nama, gajiPokok);
        this.komisi = komisi;
    }

    @Override
    public float hitungGajiTotal() {
        System.out.println("Sales: " + this.getNama());
        System.out.println("Gaji Pokok: " + this.getGajiPokok());
        System.out.println("Komisi: " + this.komisi);
        return this.getGajiPokok() + komisi;
    }
    
}
