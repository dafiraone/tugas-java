/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractabccorp;

/**
 *
 * @author dafiraone
 */
public class Manager extends Pegawai {
    private float bonus;
    
    public Manager(String nama, float gajiPokok, float bonus) {
        super(nama, gajiPokok);
        this.bonus = bonus;
    }

    @Override
    public float hitungGajiTotal() {
        System.out.println("Manager: " + this.getNama());
        System.out.printf("Gaji Pokok: %.1f \n", this.getGajiPokok());
        System.out.println("Bonus: " + this.bonus);
        return this.getGajiPokok() + this.bonus;
    }
    
}
