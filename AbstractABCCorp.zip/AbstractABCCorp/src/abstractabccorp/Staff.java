/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractabccorp;

/**
 *
 * @author dafiraone
 */
public class Staff extends Pegawai {
    private float gajiJamKerja;

    public Staff(String nama, float gajiPokok, float gajiJamKerja) {
        super(nama, gajiPokok);
        this.gajiJamKerja = gajiJamKerja;
    }

    @Override
    public float hitungGajiTotal() {
        System.out.println("Staff: " + this.getNama());
        System.out.println("Gaji Pokok: " + this.getGajiPokok());
        System.out.println("Gaji jam kerja: " + this.gajiJamKerja);
        return this.getGajiPokok() + gajiJamKerja * 8 * 30;
    }
    
}
