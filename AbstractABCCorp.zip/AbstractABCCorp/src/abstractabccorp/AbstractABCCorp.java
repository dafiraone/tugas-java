/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package abstractabccorp;

/**
 *
 * @author dafiraone
 */
public class AbstractABCCorp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Manager manager1 = new Manager("Manager1ABC", 10000000, 2000000);
        Staff staff1 = new Staff("Staff1ABC", 8000000, 15000);
        Sales sales1 = new Sales("Sales1ABC", 5000000, 200000);
        
        Pegawai[] pegawai = {manager1, staff1, sales1};
        
        for(Pegawai peg : pegawai)
        {
            System.out.printf("Gaji Total: %.1f\n", peg.hitungGajiTotal());
        }
    }
    
}
